#!/bin/bash

java -jar /usr/share/java/process.monitor.a.jar &
