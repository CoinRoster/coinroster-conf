-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 05, 2019 at 11:31 AM
-- Server version: 5.5.47-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `coinroster-test`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE IF NOT EXISTS `address` (
  `index` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `btc_address` varchar(38) NOT NULL,
  `cr_account` varchar(256) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `forwarded_to_storage` int(11) NOT NULL DEFAULT '0',
  `keys` text,
  PRIMARY KEY (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `affiliate`
--

CREATE TABLE IF NOT EXISTS `affiliate` (
  `source` varchar(20) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `session_id` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `autoplay`
--

CREATE TABLE IF NOT EXISTS `autoplay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(40) NOT NULL,
  `contest_template_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `algorithm` varchar(20) NOT NULL,
  `num_rosters` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `contest_template_id` (`contest_template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `code` varchar(20) NOT NULL,
  `description` varchar(40) NOT NULL,
  `position` int(11) DEFAULT '999',
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cgs`
--

CREATE TABLE IF NOT EXISTS `cgs` (
  `index` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cr_account` varchar(256) DEFAULT NULL,
  `btc_address` varchar(38) NOT NULL,
  `btc_u_balance` varchar(55) NOT NULL DEFAULT '0',
  `btc_c_balance` varchar(55) NOT NULL DEFAULT '0',
  `keys` text,
  `last_live_balance_check` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `contest`
--

CREATE TABLE IF NOT EXISTS `contest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` bigint(20) NOT NULL,
  `created_by` varchar(40) NOT NULL,
  `category` varchar(20) NOT NULL,
  `sub_category` varchar(20) NOT NULL,
  `contest_type` varchar(20) NOT NULL,
  `title` tinytext NOT NULL,
  `description` text NOT NULL,
  `settlement_type` varchar(40) DEFAULT NULL,
  `pay_table` text,
  `option_table` longtext NOT NULL,
  `scoring_rules` text,
  `rake` float NOT NULL,
  `salary_cap` float DEFAULT NULL,
  `cost_per_entry` decimal(16,8) NOT NULL,
  `min_users` int(11) DEFAULT '2',
  `max_users` int(11) DEFAULT '0',
  `entries_per_user` int(11) DEFAULT '0',
  `registration_deadline` bigint(20) NOT NULL,
  `status` int(11) DEFAULT '1',
  `roster_size` int(11) DEFAULT '0',
  `odds_source` varchar(400) DEFAULT NULL,
  `settled_by` varchar(40) DEFAULT NULL,
  `settled` bigint(20) DEFAULT NULL,
  `score_header` varchar(250) DEFAULT NULL,
  `scores_updated` bigint(20) DEFAULT '0',
  `scoring_scheme` varchar(20) DEFAULT NULL,
  `progressive` varchar(20) DEFAULT NULL,
  `progressive_paid` decimal(16,8) DEFAULT '0.00000000',
  `auto_settle` tinyint(1) DEFAULT NULL,
  `gameIDs` varchar(200) DEFAULT NULL,
  `settlement_deadline` bigint(20) DEFAULT NULL,
  `prop_data` text,
  `participants` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `contest_template`
--

CREATE TABLE IF NOT EXISTS `contest_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(20) NOT NULL,
  `sub_category` varchar(20) NOT NULL,
  `contest_type` varchar(20) NOT NULL,
  `title` tinytext NOT NULL,
  `description` text NOT NULL,
  `settlement_type` varchar(40) NOT NULL,
  `pay_table` text,
  `rake` float NOT NULL,
  `salary_cap` int(11) DEFAULT NULL,
  `cost_per_entry` decimal(16,8) NOT NULL,
  `min_users` int(11) NOT NULL,
  `max_users` int(11) NOT NULL,
  `entries_per_user` int(11) NOT NULL,
  `roster_size` int(11) NOT NULL,
  `multi_stat` tinyint(1) NOT NULL,
  `prop_data` text,
  `scoring_rules` text NOT NULL,
  `score_header` text NOT NULL,
  `progressive` varchar(20) DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `filter` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `control`
--

CREATE TABLE IF NOT EXISTS `control` (
  `name` varchar(50) NOT NULL DEFAULT '',
  `value` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `entry`
--

CREATE TABLE IF NOT EXISTS `entry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contest_id` int(11) NOT NULL,
  `user_id` varchar(40) NOT NULL,
  `created` bigint(20) NOT NULL,
  `amount` decimal(16,8) NOT NULL,
  `entry_data` text NOT NULL,
  `score` decimal(16,8) DEFAULT '0.00000000',
  `payout` decimal(16,8) DEFAULT '0.00000000',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `fx`
--

CREATE TABLE IF NOT EXISTS `fx` (
  `symbol` varchar(10) NOT NULL,
  `source` varchar(40) DEFAULT NULL,
  `last_price` decimal(16,8) DEFAULT '0.00000000',
  `last_updated` bigint(20) NOT NULL,
  `description` varchar(50) DEFAULT NULL,
  UNIQUE KEY `symbol` (`symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `passwords`
--

CREATE TABLE IF NOT EXISTS `passwords` (
  `key_hash` varchar(40) DEFAULT NULL,
  `data` blob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset`
--

CREATE TABLE IF NOT EXISTS `password_reset` (
  `reset_key` varchar(40) NOT NULL,
  `user_id` varchar(40) NOT NULL,
  `created` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `player`
--

CREATE TABLE IF NOT EXISTS `player` (
  `id` varchar(25) NOT NULL,
  `name` varchar(40) NOT NULL,
  `sport_type` varchar(20) NOT NULL,
  `gameID` varchar(25) NOT NULL,
  `team_abr` varchar(5) NOT NULL,
  `salary` double(10,0) NOT NULL,
  `data` text,
  `points` double(10,0) NOT NULL,
  `bioJSON` text NOT NULL,
  `filter_on` smallint(6) DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`,`sport_type`,`gameID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `progressive`
--

CREATE TABLE IF NOT EXISTS `progressive` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` bigint(20) NOT NULL,
  `created_by` varchar(40) NOT NULL,
  `category` varchar(20) NOT NULL,
  `sub_category` varchar(20) NOT NULL,
  `code` varchar(20) NOT NULL,
  `payout_info` varchar(500) NOT NULL,
  `balance` decimal(16,8) DEFAULT '0.00000000',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `promo`
--

CREATE TABLE IF NOT EXISTS `promo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` bigint(20) NOT NULL,
  `expires` bigint(20) DEFAULT '0',
  `cancelled` bigint(20) DEFAULT '0',
  `approved_by` varchar(40) NOT NULL,
  `cancelled_by` varchar(40) DEFAULT NULL,
  `promo_code` varchar(20) NOT NULL,
  `description` varchar(50) NOT NULL,
  `referrer` varchar(40) DEFAULT NULL,
  `free_play_amount` decimal(16,8) NOT NULL,
  `rollover_multiple` int(11) NOT NULL,
  `cancelled_reason` varchar(200) DEFAULT NULL,
  `max_use` int(11) DEFAULT '0',
  `times_used` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `promo_request`
--

CREATE TABLE IF NOT EXISTS `promo_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` bigint(20) NOT NULL,
  `created_by` varchar(40) NOT NULL,
  `requested_code` varchar(20) DEFAULT NULL,
  `approved` int(11) DEFAULT '0',
  `denied` int(11) DEFAULT '0',
  `denied_reason` varchar(200) DEFAULT NULL,
  `denied_by` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `quickbt`
--

CREATE TABLE IF NOT EXISTS `quickbt` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `passed_id` varchar(40) NOT NULL,
  `user_id` varchar(40) NOT NULL,
  `created` bigint(20) NOT NULL,
  `completed` bigint(20) DEFAULT '0',
  `pending_flag` int(11) DEFAULT '1',
  `cancelled_flag` int(11) DEFAULT '0',
  PRIMARY KEY (`trans_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `referral`
--

CREATE TABLE IF NOT EXISTS `referral` (
  `referral_key` varchar(40) NOT NULL,
  `referrer_id` varchar(40) NOT NULL,
  `referrer_username` varchar(40) NOT NULL,
  `email_address` varchar(60) NOT NULL,
  `referral_program` decimal(3,2) DEFAULT '0.00',
  `created` bigint(20) NOT NULL,
  `promo_code` varchar(100) DEFAULT NULL,
  UNIQUE KEY `referral_key` (`referral_key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE IF NOT EXISTS `sub_category` (
  `id` varchar(41) NOT NULL,
  `category` varchar(20) NOT NULL,
  `code` varchar(20) NOT NULL,
  `description` varchar(40) NOT NULL,
  `active_flag` int(11) DEFAULT '1',
  `image_name` varchar(70) NOT NULL,
  `created` bigint(20) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` bigint(20) NOT NULL,
  `created_by` varchar(40) NOT NULL,
  `trans_type` varchar(40) DEFAULT NULL,
  `from_account` varchar(40) NOT NULL,
  `to_account` varchar(40) NOT NULL,
  `amount` decimal(16,8) NOT NULL,
  `from_currency` varchar(3) NOT NULL,
  `to_currency` varchar(3) NOT NULL,
  `memo` varchar(500) DEFAULT NULL,
  `pending_flag` int(11) DEFAULT '0',
  `ext_address` varchar(40) DEFAULT NULL,
  `contest_id` int(11) DEFAULT NULL,
  `cancelled_flag` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` varchar(40) DEFAULT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `level` int(11) NOT NULL DEFAULT '0',
  `created` bigint(20) NOT NULL,
  `last_login` bigint(20) NOT NULL DEFAULT '0',
  `btc_balance` decimal(16,8) DEFAULT '0.00000000',
  `rc_balance` decimal(16,8) DEFAULT '0.00000000',
  `ext_address` varchar(40) DEFAULT NULL,
  `email_address` varchar(60) DEFAULT NULL,
  `email_ver_key` varchar(40) DEFAULT NULL,
  `email_ver_flag` int(11) DEFAULT '0',
  `newsletter_flag` int(11) DEFAULT '0',
  `referral_program` decimal(3,2) DEFAULT '0.00',
  `referrer` varchar(40) DEFAULT NULL,
  `ext_address_secure_flag` int(11) DEFAULT '0',
  `free_play` int(11) DEFAULT '0',
  `last_active` bigint(20) DEFAULT '0',
  `contest_status` int(11) DEFAULT '1',
  `currency` varchar(6) DEFAULT 'USD',
  `referral_offer` decimal(3,2) DEFAULT '0.50',
  `promo_code` varchar(100) DEFAULT NULL,
  `withdrawal_locked` int(11) DEFAULT '0',
  `rollover_quota` decimal(16,8) DEFAULT '0.00000000',
  `rollover_progress` decimal(16,8) DEFAULT '0.00000000',
  `first_deposit` decimal(16,8) DEFAULT '0.00000000',
  `deposit_bonus_claimed` int(11) DEFAULT '0',
  `deposit_bonus_cap` decimal(16,8) DEFAULT '0.00000000',
  `deposit_bonus_rollover_multiple` int(11) DEFAULT '0',
  `odds_format` varchar(10) DEFAULT 'DECIMAL',
  `cgs_address` varchar(40) DEFAULT NULL,
  `cgs_last_balance` decimal(16,8) DEFAULT '0.00000000',
  `referrer_key` varchar(8) DEFAULT NULL,
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `referrer_key` (`referrer_key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `verified_email`
--

CREATE TABLE IF NOT EXISTS `verified_email` (
  `user_id` varchar(40) NOT NULL,
  `email_address` varchar(60) NOT NULL,
  `created` bigint(20) NOT NULL,
  PRIMARY KEY (`email_address`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `voting`
--

CREATE TABLE IF NOT EXISTS `voting` (
  `id` int(11) NOT NULL,
  `original_contest_id` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
