CREATE DATABASE coinroster;
USE coinroster;
