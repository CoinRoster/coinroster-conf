#!/bin/bash

pkill -f nlphd.server.jar
